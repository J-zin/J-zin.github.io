import math
import torch
import numpy as np
import torch.autograd as autograd
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module

class Boltzmann_Machine(Module):
    def __init__(self, in_features, ratio = True):
        super(Boltzmann_Machine, self).__init__()
        self.in_features = in_features
        self.weight = Parameter(torch.zeros([in_features, in_features], dtype=torch.float32))
        self.bias = Parameter(torch.zeros([in_features], dtype=torch.float32))
        self.reset_parameters()
        self.ratio = ratio

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        tmp = torch.FloatTensor(self.weight.size(0), self.weight.size(1)).uniform_(-stdv, stdv)
        self.weight.data = 0.5 * (tmp + tmp.transpose(-1, -2))
        self.bias.data.uniform_(-stdv, stdv)
    
    def set_parameters(self, M, b):
        self.weight.data = M
        self.bias.data = b

    def forward(self, x):
        if self.ratio:
            output = torch.exp(2 * x.transpose(0, 1).mul(self.weight.matmul(x.transpose(0, 1))).transpose(0,1) + 2 * x.mul(self.bias))
            output = 1/torch.pow((1+ output), 2)
        else:
            output = torch.exp(- 2 * x.transpose(0, 1).mul(self.weight.matmul(x.transpose(0, 1))).transpose(0, 1) - 2 * x.mul(self.bias))
            output = torch.pow(output, 2)
        return output
    
    def forward_grm(self, x):
        score = 0.5 * x.matmul((self.weight + self.weight.transpose(-1,-2))) + self.bias
        diag_hessian = torch.diag(0.5 * (self.weight + self.weight.transpose(-1,-2)))

        output = score ** 2 + 2 * diag_hessian
        return output

    def set_weight_grad(self):
        grad = self.weight.grad.data
        self.weight.grad.data = 0.5 * (grad + grad.transpose(0, 1))

    def get_weight(self):
        return self.weight.data

    def get_bias(self):
        return self.bias.data


class Oracle_BM(object):
    def __init__(self, ini_M, ini_b):
        self.weight = ini_M
        self.bias = ini_b
    
    def log_energy(self, x):
        return 0.5 * x.unsqueeze(1).matmul(self.weight).bmm(x.unsqueeze(-1)).squeeze() + x.matmul(self.bias.unsqueeze(-1)).squeeze()

    def score(self, samples):
        with torch.enable_grad():
            samples = samples.detach()
            samples.requires_grad_(True)
            log_energy = self.log_energy(samples).sum()
            score = autograd.grad(log_energy, samples)[0]
            return score.detach()