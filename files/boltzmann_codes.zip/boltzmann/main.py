import os
os.environ['KMP_DUPLICATE_LIB_OK']='True'
import copy
import torch
import numpy as np
import torch.optim as optim
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader

from utils.data_utils import collate
from model.Boltzmann import Boltzmann_Machine, Oracle_BM

sigma = 0.25
n_dim = 6
num_samples = 1000
lr_init = 0.001
lr_ini_score_pytorch = 0.0001
lr_ini_discrete_score = 0.0001
lr_ini_ratio = 0.01
weight_decay = 0
all_samples = []
all_samples_prob = []
training_epochs = 1500
batch_size = num_samples


def get_all_samples(pos, x):
    if pos > len(x)-1:
        return
    if pos == 0:
        all_samples.append(x)
    x_copy = np.copy(x)
    get_all_samples(pos+1, x_copy)
    x_copy[pos] = 1
    all_samples.append(x_copy)
    get_all_samples(pos+1, x_copy)
    return

def gen_sample(prob_list, all_samples):
    gen_samples = []
    while len(gen_samples)<num_samples:
        random_num = np.random.rand()
        for j in range(len(prob_list)):
            random_num = random_num - prob_list[j]
            if random_num <= 0:
                gen_samples.append(all_samples[j])
                break
    return gen_samples

def loss_func(output):
    loss = output.sum(-1).sum()/output.shape[0]
    return loss, loss.detach().cpu().item()

def evaluate(model, ini_M):
    M = model.get_weight()
    dis = np.linalg.norm(M.view(-1).unsqueeze(0).numpy() - ini_M.view(-1).unsqueeze(0).numpy())
    return dis

def train_ratio_matching(train_loader, optimizer, model, ini_M):
    total_loss = []
    total_dis = []

    for i in range(training_epochs):
        model.train()
        loss_list = []
        for feat in train_loader:
            optimizer.zero_grad()
            output = model(feat)
            loss, loss_items = loss_func(output)
            loss_list.append(loss_items)
            loss.backward()
            model.set_weight_grad()
            optimizer.step()
        total_loss.append(sum(loss_list)/len(loss_list))
        dis = evaluate(model, ini_M)
        total_dis.append(dis)

    return total_dis, total_loss

def train_general_score_matching(train_loader, optimizer, model, ini_M):
    total_loss = []
    total_dis = []

    for i in range(training_epochs):
        model.train()
        loss_list = []

        for feat in train_loader:
            optimizer.zero_grad()
            output = model(feat)
            loss, loss_items = loss_func(output)
            loss_list.append(loss_items)
            loss.backward()
            model.set_weight_grad()
            optimizer.step()
        total_loss.append(sum(loss_list) / len(loss_list))
        dis = evaluate(model, ini_M)
        total_dis.append(dis)
    return total_dis, total_loss

def train_gradient_ratio_matching(train_loader, optimizer, model, ini_M):
    total_loss = []
    total_dis = []

    for i in range(training_epochs):
        model.train()
        loss_list = []

        for feat in train_loader:
            optimizer.zero_grad()
            output = model.forward_grm(feat)
            loss, loss_items = loss_func(output)
            loss_list.append(loss_items)
            loss.backward()
            model.set_weight_grad()
            optimizer.step()
        total_loss.append(sum(loss_list) / len(loss_list))
        dis = evaluate(model, ini_M)
        total_dis.append(dis)
    return total_dis, total_loss

if __name__ == "__main__":
    torch.manual_seed(1111)
    ini_M = torch.randn((n_dim, n_dim), dtype=torch.float32).triu(diagonal=1) * sigma
    ini_M = ini_M + ini_M.transpose(-1, -2)
    ini_b = torch.randn(n_dim, dtype=torch.float32) * sigma

    x_ini = np.zeros(n_dim)
    get_all_samples(0, x_ini)
    all_samples = torch.FloatTensor(all_samples)
    scores = torch.exp(0.5 * all_samples.unsqueeze(1).matmul(ini_M).bmm(all_samples.unsqueeze(-1)).squeeze() + all_samples.matmul(ini_b.unsqueeze(-1)).squeeze())
    scores = scores.numpy()
    prob = scores/scores.sum()
    gen_samples = gen_sample(prob, all_samples)

    # raio matching
    model_rm = Boltzmann_Machine(n_dim)
    M_fixed, b_fixed = model_rm.get_weight().clone(), model_rm.get_bias().clone()
    optimizer_rm = optim.Adam(model_rm.parameters(), lr=lr_ini_score_pytorch)
    train_loader_rm = DataLoader(dataset=gen_samples, batch_size=batch_size, shuffle=False, collate_fn=collate)
    dis_rm, loss_rm = train_ratio_matching(train_loader_rm, optimizer_rm, model_rm, ini_M)
    
    # general score matching
    model_gsm = Boltzmann_Machine(n_dim, ratio = False)
    model_gsm.set_parameters(copy.deepcopy(M_fixed), copy.deepcopy(b_fixed))
    optimizer_gsm = optim.Adam(model_gsm.parameters(), lr=lr_ini_score_pytorch)
    train_loader_gsm = DataLoader(dataset=gen_samples, batch_size=batch_size, shuffle=False, collate_fn=collate)
    dis_gsm, loss_gsm = train_general_score_matching(train_loader_gsm, optimizer_gsm, model_gsm, ini_M)


    # gradient ratio matching
    model_grm = Boltzmann_Machine(n_dim, ratio = False)
    model_grm.set_parameters(copy.deepcopy(M_fixed), copy.deepcopy(b_fixed))
    optimizer_grm = optim.Adam(model_grm.parameters(), lr=lr_ini_score_pytorch)
    train_loader_grm = DataLoader(dataset=gen_samples, batch_size=batch_size, shuffle=False, collate_fn=collate)
    dis_grm, loss_grm = train_gradient_ratio_matching(train_loader_grm, optimizer_grm, model_grm, ini_M)

    x1 = range(0, len(loss_rm))
    x2 = range(0, len(dis_rm))
    plt.subplot(2, 1, 1)
    plt.plot(x1, loss_rm, 'r-', label = u'Ratio Matching')
    plt.plot(x1, loss_gsm, 'y-', label = u'General Score Matching')
    plt.plot(x1, loss_grm, 'b-', label = u'Gradient Ratio Matching')
    plt.legend()
    plt.xlabel('Epochs')
    plt.ylabel('Loss')

    plt.subplot(2, 1, 2)
    plt.plot(x2, dis_rm, 'r-', label = u'Ratio Matching')
    plt.plot(x2, dis_gsm, 'y-', label=u'General Score Matching')
    plt.plot(x2, dis_grm, 'b-', label = u'Gradient Ratio Matching')
    plt.legend()
    plt.xlabel('Epochs')
    plt.ylabel('Euclidean Distance')
    plt.tight_layout()
    # plt.show()
    plt.savefig('result.png')


    