import torch
from torch.utils.data import Dataset

def collate(data):
    feat_list = []
    for feat in data:
        feat_list.append(feat)
    return torch.stack(feat_list)